document.getElementById("chat-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const userInput = document.getElementById("user-input").value.trim();
    if (!userInput) return;

    const messagesDiv = document.getElementById("messages");
    
    // Display user message
    const userMessageDiv = document.createElement("div");
    userMessageDiv.className = "message user";
    userMessageDiv.textContent = userInput;
    messagesDiv.appendChild(userMessageDiv);
    
    document.getElementById("user-input").value = "";

    // Show loading
    const loadingDiv = document.getElementById("loading");
    loadingDiv.style.display = "block";

    try {
        const response = await fetch("/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: userInput }),
        });

        const data = await response.json();

        // Display bot responses
        data.responses.forEach((response) => {
            const botMessageDiv = document.createElement("div");
            botMessageDiv.className = "message bot";
            
            // Format check-in messages
            if (response.includes("Daily Check-In")) {
                botMessageDiv.innerHTML = response
                    .replace(/\n/g, "<br>")
                    .replace(/(\d+\.)/g, "<strong>$1</strong>");
            } else {
                botMessageDiv.innerHTML = response
                    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
                    .replace(/\*(.*?)\*/g, "<em>$1</em>")
                    .replace(/\n/g, "<br>");
            }
            
            messagesDiv.appendChild(botMessageDiv);
        });

        messagesDiv.scrollTop = messagesDiv.scrollHeight;
        loadingDiv.style.display = "none";
        
    } catch (error) {
        console.error(error);
        const errorMessageDiv = document.createElement("div");
        errorMessageDiv.className = "message bot";
        errorMessageDiv.textContent = "An error occurred. Please try again.";
        messagesDiv.appendChild(errorMessageDiv);
        loadingDiv.style.display = "none";
    }
});
